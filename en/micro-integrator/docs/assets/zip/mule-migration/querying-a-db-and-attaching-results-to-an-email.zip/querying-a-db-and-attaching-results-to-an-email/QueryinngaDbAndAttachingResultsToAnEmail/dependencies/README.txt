README

===============================================================================


This directory contains downloaded drivers.

Drivers will not get deployed with other artifacts (in your CApp).

Be sure to manually copy the drivers from this directory to <PRODUCT_HOME>/lib/.