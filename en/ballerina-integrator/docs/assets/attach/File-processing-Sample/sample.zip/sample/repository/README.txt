Copy this repository directory into the MI Root directory. Please note that this will overwrite the existing main and fault xml files.
