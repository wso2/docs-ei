Guide on File Integration using the FTP Connector.

# Guide Overview

The WSO2 FTP Connector enables you to connect to an FTP server and perform operations on files and folders stored on the
server. These operations include basic file operations such as reading, updating, and deleting files, and listening to
the server to invoke operations when a file is created or deleted.

> In this guide you will learn how to use the WSO2 FTP Connector to create an FTP listener service using Ballerina.

The following are the sections available in this guide.

- [What you'll build](#what-youll-build)
- [Prerequisites](#prerequisites)
- [Implementation](#implementation)
- [Testing](#testing)

## What you'll Build

To understand how to build a service to listen to an FTP server, let's consider the use case of a data center that uses
an FTP server to store data files. When a new file is added to the server, the FTP listener will read the file and add
the file name and size to a map, and when the file is deleted from the server, it will remove the entry from the map.

![File integration using FTP](resources/file-integration-using-ftp.png)

## Prerequisites

- Java
- Ballerina Integrator
> **Tip**: For a better development experience, install the Ballerina Integrator extension in [VS Code](https://code.visualstudio.com).
- An FTP Server (See [here](https://www.digitalocean.com/community/tutorials/how-to-set-up-vsftpd-for-a-user-s-directory-on-ubuntu-16-04) on how to setup an FTP server)

## Implementation
> If you want to skip the basics, you can download the GitHub repo and directly move to the "Testing" section by skipping the "Implementation" section.

Create the Ballerina project `file-integration-using-ftp` and add the `file_integration_using_ftp` module using the below commands.

```bash
$ ballerina new file-integration-using-ftp
$ cd file-integration-using-ftp
$ ballerina add file_integration_using_ftp
```

The above package structure will be created for you. Create the `ftp_listener.bal` file inside the Ballerina module.

### Developing the FTP listener service

Let's start implementation by importing the WSO2 FTP Connector in the `ftp_listener.bal` file which you just created.
This will pull the FTP Connector from Ballerina Central.

```ballerina
import wso2/ftp;
```

Next, let's create an FTP Listener instance by defining the configuration in the `Ballerina.conf` file. The `FTP_HOST`
is the IP address of the FTP server, while the `FTP_USERNAME` and `FTP_PASSWORD` are credentials of a user that has permission
to access the FTP server. The `FTP_HOST` is the port used to connect with the server, of which the default value is `21`.

Then you can add the configurations for the type of files the listener should listen for. For instance, if listener
should be invoked for text files, the config for `FTP_FILE_NAME_PATTERN` should be set as `(.*).txt`. Next, add
the location to poll for files and how frequently the listener should poll for files, using the values
`FTP_LISTENER_PATH` and `FTP_POLLING_INTERVAL`respectively.

Create the service to listen to the FTP server using the above listener. When files are added or deleted on the server,
this service will be invoked, and the files will be processed.

Then implement the FTP Client, which will connect to the FTP server and get the details of new files to process.

Declare a map to store the details of processed files.

```ballerina
map<int> fileMap = {};
```

Now, implement the processing of added and deleted files. When files are added to the server, the FTP client will
retrieve the file size from the server, and the file name and its size will be added to the `fileMap`. When a file is
removed from the server, the file will be removed from the map.

## Testing

### Invoking the service

To begin with invoking the service, start the FTP server.

Navigate to `file-integration-using-ftp` directory and run the following command to build the listener service in `ftp_listener.bal`.

```bash
$ ballerina build file_integration_using_ftp
```

The successful build of a service will show us something similar to the following output.

```
Compiling source
        wso2/file_integration_using_ftp:0.1.0

Creating balos
        target/balo/file_integration_using_ftp-2019r3-java8-0.1.0.balo
```

This will create the Ballerina executables inside the `/target` directory.

Then run the jar file created in the above step.

```bash
$ java -jar target/bin/file_integration_using_ftp.jar --b7a.config.file=src/file_integration_using_ftp/resources/ballerina.conf
```

Add and delete files in the FTP server, and check the logs to verify whether the service is working as expected.
