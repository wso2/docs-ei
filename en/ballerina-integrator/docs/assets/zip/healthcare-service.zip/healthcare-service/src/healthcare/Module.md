# Healthcare Service

This is the sample service used for guides and examples.
